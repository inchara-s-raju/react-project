import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import './App.css';
import Login from './Components/Login';
import Navbar from './Components/Navbar';


function App() {
  return (
  <Router>
   <Navbar />
   <Routes>
    <Route path='/Login' element={<Login/>}></Route>
   </Routes>
   </Router>
  );
}

export default App;
